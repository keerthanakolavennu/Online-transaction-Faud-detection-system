from django.apps import AppConfig


class OnlinetransactionfrauddetectionappConfig(AppConfig):
    name = 'OnlineTransactionFraudDetectionApp'

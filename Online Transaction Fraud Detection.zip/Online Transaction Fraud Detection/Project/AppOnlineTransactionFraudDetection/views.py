from django.shortcuts import render,redirect
from django.db.models import Sum,Max
from django import template
from django.contrib.sessions.models import Session
import string
from django.core.files.storage import FileSystemStorage
from django.utils.module_loading import import_string
from datetime import date
from django.http import HttpResponse
from AppOnlineTransactionFraudDetection.models import User_details,Blockrequest, Products, Card_details, Order_details, Cart, Admin_Details  
from AppOnlineTransactionFraudDetection.forms import User_details
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.models import User, auth
from django.db.models import Avg, Max, Min, Sum, Count
import re
import math
from django.core.files.storage import FileSystemStorage
from django.views.decorators.csrf import csrf_exempt


# Create your views here.

def home(request):
    return render(request,'home.html',{})


def about(request):
    return render(request,"about.html",{})





def register(request):

    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['Username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['Email']
        cardnumber = request.POST['Cardnumber']
        cvv = request.POST['Cvv']
        Expirydate =  request.POST['Expiry_month'] + request.POST['Expiry_year']
        mobile = request.POST['Mobile']
        securityquestion1 = request.POST['SecurityQuestion1']
        answer1 = request.POST['SecurityAnswer1']
        securityquestion2 = request.POST['SecurityQuestion2']
        answer2 = request.POST['SecurityAnswer2']
        securityquestion3 = request.POST['SecurityQuestion3']
        answer3 = request.POST['SecurityAnswer3']

        if password1==password2:
            if User_details.objects.filter(Username=username).exists():
                #messages.info('request','username Taken')
                print('username taken')
                return redirect('/register/')

            elif User_details.objects.filter(Email=email).exists():
                messages.info('request','Email Id taken')
                return redirect('/register/')

            else:
                register1 = User_details( FirstName=first_name,LastName=last_name,Email=email,Username=username,Password=password1, Card_number=cardnumber ,cvv= cvv,Expirydate= Expirydate,mobile= mobile,Securityquestion1=securityquestion1,Securityanswer1=answer1,Securityquestion2=securityquestion2,Securityanswer2=answer2,Securityquestion3=securityquestion3,Securityanswer3=answer3 )
                register1.save()
                print('User Created')
                messages.info(request,'User Registered')
                return redirect('/User_login/')
        else:
            messages.info(request,'Password doesnt match')
            return redirect('/register/')
    else:
        return render(request,"register.html",{})


def Admin_login(request):
    if request.method == 'POST':
        Username = request.POST['Username']
        password = request.POST['password']
        
        if Admin_Details.objects.filter(Username=Username, Password=password).exists():
                user = Admin_Details.objects.get(Username=Username, Password=password)
                request.session['type_id'] = 'Admin'
                request.session['username'] = Username
                request.session['login'] = 'Yes'
                return redirect('/')
        else:
            messages.info(request,'Invalid Credentials')
            return redirect('/Admin_login/')
    else:
        return render(request, 'Admin_login.html', {})


def User_login(request):
    if request.method == 'POST':
        Username = request.POST['Username']
        password = request.POST['password']
        
        if User_details.objects.filter(Username=Username, Password=password).exists():
            user = User_details.objects.all().filter(Username=Username, Password=password)
            status = user[0].status
            if status == 'blocked':
                request.session['Blocked'] = 'Yes'
            else:
                request.session['Blocked'] = 'No'
            request.session['User_id'] = str(user[0].id)
            request.session['type_id'] = 'User'
            request.session['username'] = Username
            request.session['login'] = 'Yes'
            return redirect('/')
        else:
            messages.info(request,'Invalid Credentials')
            return redirect('/User_login/')
    else:
        return render(request, 'User_login.html', {})


'''def login(request):
    if request.method == 'POST':
        print('post')
        username = request.POST['username']
        password = request.POST['password']
        
        user = auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request, user)
            print('login')
            current_user = request.user
            Uid = current_user.id
            if current_user.is_superuser:
                print('superuser')
                return redirect("/dashboard/")
            else:
                sus = User_details.objects.all().filter(id=Uid)
                print(sus[0].status)
                if sus[0].status == 'blocked':
                    request.session['blocked'] = 'yes'
                    print(request.session['blocked'])
                    return redirect("/blocked/")
                else:
                    request.session['blocked'] = 'no'
                    print(request.session['blocked'])
                    return redirect("/dashboard/")
        else:
            messages.info(request,'invalid credentials')
            return redirect('login')
    else:
        return render(request,"login.html",{})'''


def logout(request):
    Cart.objects.all().delete()
    Session.objects.all().delete()
    return redirect('/')




def dashboard(request):
    products= Products.objects.all()
    return render(request,"Dashboard.html",{'products':products})


def addtocart(request):
    if request.method == 'POST':  
        Uid = request.session['User_id']
        users = User_details.objects.all().filter(id=Uid)
        cardnum = request.POST['Credit/Debit']
        cvv = request.POST['Cvv']
        expiry = request.POST['Expiry_month'] + request.POST['Expiry_year']
        cnum=users[0].Card_number
        print(cardnum)
        cv = users[0].cvv
        print(cvv)
        ex =  users[0].Expirydate
        print(expiry)

        if str(cnum) == str(cardnum) and str(cv) == str(cvv) and str(ex) == str(expiry):
            today = date.today()
            current_user = request.user
            d1 = today.strftime("%d/%m/%Y")
            tid = list(Order_details.objects.aggregate(Max('Tid')).values())[0] or 0
            finaltid = int(tid)+1
            Tid = finaltid
            Tdate = d1
            Uid = request.session['User_id']
            Totalamount = int(request.POST['TotalAmount'])       
            Quantity = request.POST['hiddenfieldquantity']
            Quantity=Quantity[:-1]
            productlist = request.POST['hiddenfieldname']
            productlist=productlist[:-1]

            
            count = Order_details.objects.all().filter(Uid=Uid).count()
            if count > 0:
                aggregateamount = Order_details.objects.all().filter(Uid=Uid).aggregate(Avg('TotalAmount'))
                s = str(aggregateamount)

                s = s.replace("{'TotalAmount__avg':", '')
                s = s.replace('}', '')
                s = s.replace(' ', '')
                
                s = int(float(s))

                print('s',s)
                per = (20/100)*s

                per = int(float(per))
                print('Your Percentage is:',per)

                MaxAmount = s + per
                MinAmount = s - per
            
                if Totalamount > MaxAmount or Totalamount < MinAmount : 
                    status = 'Pending'
                    add_orders = Order_details( Tid=Tid, Uid=Uid ,TotalAmount= Totalamount,date= Tdate,productList= productlist,quantity=Quantity,status=status )
                    add_orders.save()
                    Cart.objects.all().delete()
                    order = Order_details.objects.all().filter(Tid=Tid)
                    td= str(Tid)
                    request.session['Tid'] = Tid
                    messages.info(request,'Order pending for verification') 
                    return redirect("/verify/"+ td,{})
                else:
                    status = 'Ordered'
                    add_orders = Order_details( Tid=Tid, Uid=Uid ,TotalAmount= Totalamount,date= Tdate,productList= productlist,quantity=Quantity,status=status )
                    add_orders.save()
                    Cart.objects.all().delete()
                    messages.info(request,'Order placed successfully') 
                    return redirect("/dashboard/")
            else:
                status = 'Ordered'
                add_orders = Order_details( Tid=Tid, Uid=Uid ,TotalAmount= Totalamount,date= Tdate,productList= productlist,quantity=Quantity,status=status )
                add_orders.save()
                Cart.objects.all().delete()
                messages.info(request,'Order placed successfully') 
                return redirect("/dashboard/")
        else:
            Carts = Cart.objects.all()
            #Cart.objects.all().aggregate(Sum('cost'))['cost__sum'] or 0.00
            total = list(Cart.objects.aggregate(Sum('total')).values())[0] or 0.00 
            messages.info(request,'details doesnt match')    
            return render(request,"AddtoCart.html",{'Carts':Carts,'total': total})


    else:
        Carts = Cart.objects.all()
        #Cart.objects.all().aggregate(Sum('cost'))['cost__sum'] or 0.00
        total = list(Cart.objects.aggregate(Sum('total')).values())[0] or 0.00     
        return render(request,"AddtoCart.html",{'Carts':Carts,'total': total})


def productdetails(request,id):
    if request.method == 'POST':
        userid = request.POST['uid']
        product_name = request.POST['pname']
        cost = request.POST['pcost']
        category = request.POST['category']
        Quantity = request.POST['Quantity']
        pid = request.POST['pid']
        if Cart.objects.filter(Pname=product_name).exists():
            sus = Cart.objects.all().filter(Pname=product_name)
            totalqty= int(Quantity) + int(sus[0].qty)
            totalamount= int(cost) * int(totalqty)
            #update query
            Cart.objects.filter(id=sus[0].id).update(qty=totalqty,total=totalamount)           
        else:
            totalamount= int(cost) * int(Quantity)
            add_cart = Cart( Pid=pid, Pname=product_name ,qty= Quantity,cost= cost,Uid= userid,total=totalamount,category=category )
            add_cart.save()              
        return redirect('/addtocart/',{})
        
    else:
        product = Products.objects.get(id=id)
        return render(request,"ProductDetails.html",{'product':product})


def deleteFromcart(request,id):
    Carts = Cart.objects.get(id=id)
    Carts.delete()
    messages.info(request,'Item removed from cart')
    return redirect('/addtocart/',{})


def ordersuccess(request):
    return render(request,"OrderSuccess.html",{})


def verify1(request,id): 
    if request.method == 'POST':

        Uid = request.session['User_id']
        product = User_details.objects.all().filter(id=Uid)
        if int(product[0].attempts) <= 2:
            print('enter')
            answer1 = request.POST['answer1']
            answer2 = request.POST['answer2']
            answer3 = request.POST['answer3']
            Securityanswer1 = product[0].Securityanswer1
            Securityanswer2 = product[0].Securityanswer2
            Securityanswer3 = product[0].Securityanswer3
            if Securityanswer1 == answer1 and  Securityanswer2 == answer2 and Securityanswer3 == answer3:
                print('success')
                Tid = request.session['Tid']
                Order_details.objects.filter(Tid=Tid).update(status='Ordered')
                messages.info(request,'Order placed successfully') 
                return redirect("/dashboard/")
            else:
                print('fail') 
                att = int(product[0].attempts)+1
                User_details.objects.filter(id=Uid).update(attempts=att)
                q1 = product[0].Securityquestion1
                q2 = product[0].Securityquestion2
                q3 = product[0].Securityquestion3
                Tid = request.POST['tid']
                Orders = Order_details.objects.all().filter(Tid=Tid)
                td= str(Tid)
                messages.info(request,'Answer Doesnt match in 3 attempts you will be blocked' )
                return redirect("/verify/"+ td,{'q1':q1,'q2':q2,'q3':q3,'Orders':Orders})
                #return render(request,"verify.html",{'q1':q1,'q2':q2,'q3':q3})

        else:
            Uid = request.session['User_id']
            print('block')
            User_details.objects.filter(id=Uid).update(status='blocked')
            Tid = request.session['Tid']
            Order_details.objects.filter(Tid=Tid).update(status='Rejected')
            messages.info(request,'Your Account is been Blocked') 
            return redirect('/logout/',{})
    else:
        Tid = request.session['Tid']
        print(Tid)
        Orders = Order_details.objects.all().filter(Tid=Tid)
        Uid = request.session['User_id']
        product = User_details.objects.all().filter(id=Uid)
        q1 = product[0].Securityquestion1
        q2 = product[0].Securityquestion2
        q3 = product[0].Securityquestion3
        td= str(Tid)
        #return redirect("/verify/"+ td,{'q1':q1,'q2':q2,'q3':q3,'Orders':Orders})
        return render(request,"verify.html",{'q1':q1,'q2':q2,'q3':q3,'Orders':Orders})



def blocked(request):
    if request.method == 'POST':
        userid = request.POST['Uid']
        cardnumber = request.POST['CardNumber']
        cvv = request.POST['Cvv']
        issue =  request.POST['Issue']
        Uid = request.session['User_id']
        blockid = Blockrequest.objects.all().filter(id=Uid)
        if Blockrequest.objects.filter(id=userid).exists():
            user = User_details.objects.all().filter(id=Uid)
            messages.info(request,'Request previously generated') 
            return render(request,'blockedUser.html',{'user':user})
        else:
            block = Blockrequest(id=userid, Card_number=cardnumber ,cvv= cvv,Issue= issue )
            block.save()
            user = User_details.objects.all().filter(id=Uid)
            messages.info(request,'Request Generated') 
            return render(request,'blockedUser.html',{'user':user})
            

    else:
        Uid = request.session['User_id']
        print('Uid',Uid)
        user = User_details.objects.all().filter(id=Uid)
        print(user[0].id)       
        return render(request,'blockedUser.html',{'user':user})
       


def vieworders(request,):
    Order= Order_details.objects.all()
    return render(request,'vieworders.html',{'Order':Order})




def addproduct(request):
    if request.method == 'POST':
        pid = list(Products.objects.aggregate(Max('Pid')).values())[0] or 0
        finalpid = int(pid)+1
        pid = finalpid
        ProductName = request.POST['ProductName']
        Category = request.POST['Category']
        subcategory = request.POST['subcategory']
        cost = request.POST['cost']
        Description = request.POST['Description']
        quantity = request.POST['quantity']
        filesupload = request.FILES['file_upload']
        addproduct = Products( Pid=pid, pname=ProductName ,category= Category,subcategory= subcategory,cost= cost,desc=Description,quantity=quantity,image=filesupload,)
        addproduct.save()
        messages.info(request,'Product Added')
        return redirect('/addproduct/')
    else:
        return render(request,'addproduct.html',{}) 

def updatestatus(request,id):
    Order_detail = Order_details.objects.get(id=id)
    Order_details.objects.filter(id=id).update(status='Accepted')
    messages.info(request,'Order Accepted')
    return redirect('/vieworders/',{})


def unblock(request,id):
    blockid = Blockrequest.objects.get(id=id)
    print(blockid.id)
    User_details.objects.filter(id=blockid.id).update(status='Unblocked')
    User_details.objects.filter(id=blockid.id).update(attempts=0)
    blockid.delete()
    messages.info(request,'User Unblocked')
    return redirect('/unblockrequests/',{})


def unblockrequests(request):
    Order= Blockrequest.objects.all()
    return render(request,'unblockusers.html',{'Order':Order})
    
@csrf_exempt    
def uploadimage(request):
    if request.method == 'POST':
        body = request.body.decode('utf-8')
        print(body)    #     fs = FileSystemStorage()
    #     filename = fs.save(myfile.name, myfile)
    #     uploaded_file_url = fs.url(filename)
    #     return render(request, 'core/simple_upload.html', {
    #         'uploaded_file_url': uploaded_file_url
    #     })
    # return render(request, 'core/simple_upload.html')